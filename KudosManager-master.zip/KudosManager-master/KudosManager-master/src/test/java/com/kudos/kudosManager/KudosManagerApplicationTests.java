package com.kudos.kudosManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KudosManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
