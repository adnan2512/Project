package com.kudos.kudosManager.controller;

import com.kudos.kudosManager.entity.ProjectEntity;
import com.kudos.kudosManager.entity.ProjectUserEntity;
import com.kudos.kudosManager.entity.UserEntity;
import com.kudos.kudosManager.model.ProjectUser;
import com.kudos.kudosManager.model.User;
import com.kudos.kudosManager.service.ProjectUserService;
import com.kudos.kudosManager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class ProjectUserController {

    @Autowired
    ProjectUserService projectUserService;

    @Autowired
    UserService userService;

    @GetMapping(value = "/viewRequestedUser/{id}")
    public List<UserEntity> findAllUserForOneProjectByUserId(@PathVariable Long id) {

        List<Long> userIds = projectUserService.findAllUserForOneProjectByProjectId(id);
        return userService.findAllByIdContains(userIds);
    }
    @PostMapping(value = "/usersRequest/{id}", consumes = {"application/json"})
    public ResponseEntity<ProjectUserEntity> sendRequest(@RequestBody ProjectUser projectUser,@PathVariable Long id ) throws Exception {
        return new ResponseEntity<>(projectUserService.sendRequest(projectUser,id), HttpStatus.CREATED);
    }



    @PutMapping(value = "/projectAcceptReject/{id}")
    public ResponseEntity<ProjectUserEntity> setUserStatus(@PathVariable Long id,@RequestBody ProjectUser projectUser){
        try {
            return new ResponseEntity<>(projectUserService.setUserStatus(id,projectUser), HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();

        }
        return null;
    }



}
