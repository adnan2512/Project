package com.kudos.kudosManager.service;

import com.kudos.kudosManager.entity.ProjectUserEntity;
import com.kudos.kudosManager.entity.UserEntity;
import com.kudos.kudosManager.mapper.ProjectUserServiceMapper;
import com.kudos.kudosManager.mapper.UserServiceMapper;
import com.kudos.kudosManager.model.Project;
import com.kudos.kudosManager.model.ProjectUser;
import com.kudos.kudosManager.model.User;
import com.kudos.kudosManager.repository.ProjectRepository;
import com.kudos.kudosManager.repository.ProjectUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class ProjectUserService {
    @Autowired
    ProjectUserRepository repository;

    public List<Long> findAllUserForOneProjectByProjectId(Long id) {
        List<ProjectUserEntity> projectUserEntities = repository.findAllByProjectid(id);
        List<Long> userIds = new ArrayList<>();
        for (ProjectUserEntity projectUserEntity: projectUserEntities) {
            userIds.add(projectUserEntity.getUserid());
        }

        return userIds;
    }
    public ProjectUserEntity sendRequest(ProjectUser projectUser, Long id) throws Exception {
        return repository.save(ProjectUserServiceMapper.sendRequest(projectUser,id));
    }

    public ProjectUserEntity setUserStatus(Long id,ProjectUser projectUser) throws Exception {

            return repository.save(ProjectUserServiceMapper.setUserStatus(id,projectUser));
    }


}
