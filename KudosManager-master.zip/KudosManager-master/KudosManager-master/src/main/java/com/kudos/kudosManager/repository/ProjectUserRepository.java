package com.kudos.kudosManager.repository;

import com.kudos.kudosManager.entity.ProjectEntity;
import com.kudos.kudosManager.entity.ProjectUserEntity;
import com.kudos.kudosManager.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProjectUserRepository extends JpaRepository<ProjectUserEntity,Long> {

    //@Query("select pe.name from ProjectEntity pe join ProjectUserEntity  pue where pue.id= ?1   ")
    //List<ProjectEntity> findAllProjectByUserId(int id);
    //to view all user who has reuqest for the given project under one manager
 //    @Query("select userid from ProjectUserEntity where ProjectUserEntity.projectid= ?1")

    List<ProjectUserEntity> findAllByProjectid(Long projectid);

    ProjectUserEntity findByUserid(Long userid);


    @Query("update ProjectUserEntity pue set pue.status='Accepted' where pue.userid=?1")
    List<ProjectUserEntity> setUserStatus(Long id);

}
