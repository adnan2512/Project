package com.kudos.kudosManager.mapper;

import com.kudos.kudosManager.entity.ProjectUserEntity;
import com.kudos.kudosManager.entity.UserEntity;
import com.kudos.kudosManager.model.ProjectUser;
import com.kudos.kudosManager.model.User;
import org.springframework.web.bind.annotation.PathVariable;

public class ProjectUserServiceMapper {
    public static ProjectUserEntity sendRequest(ProjectUser projectUser, Long id) {
        ProjectUserEntity projectUserEntity = new ProjectUserEntity();
        projectUserEntity.setId(projectUser.getId());
        projectUserEntity.setProjectid(projectUser.getProjectid());
        projectUserEntity.setStatus("Pending");
        projectUserEntity.setUserid(id);


        return projectUserEntity;
    }

    public static ProjectUserEntity setUserStatus(Long id,ProjectUser projectUser)
    {
        ProjectUserEntity projectUserEntity = new ProjectUserEntity();
        projectUserEntity.setUserid(id);
        projectUserEntity.setProjectid(projectUser.getProjectid());
        projectUserEntity.setStatus(projectUser.getStatus());
        projectUserEntity.setId(projectUser.getId());
        return projectUserEntity;
    }
}

