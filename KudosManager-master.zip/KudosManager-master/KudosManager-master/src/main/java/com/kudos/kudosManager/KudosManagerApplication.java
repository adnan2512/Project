package com.kudos.kudosManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KudosManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KudosManagerApplication.class, args);
	}

}
